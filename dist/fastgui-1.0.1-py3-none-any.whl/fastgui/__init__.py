'''
`testgui`\n
	>>> testgui(js:dict,pth:str=None,ifname=False,ico='1.ico')->list
	>>> testgui(js:dict,pth:str=None,ifname=False,ico='1.ico')->list
'''

from fastgui._testgui import testgui
from fastgui._matrixgui import mtgui,DESTROY,JUMP