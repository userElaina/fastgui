'''
`testgui`

	>>> testgui(js:dict,pth:str=None,ifname=False,ico='1.ico')->list
'''

from fastgui._testgui import testgui